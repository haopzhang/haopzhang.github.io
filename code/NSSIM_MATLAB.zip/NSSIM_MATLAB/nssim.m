function NSSIM = nssim(img1)

img2=reblur(img1);

[M N] = size(img1);

window = fspecial('gaussian', 11, 1.5);	%window
K1 = 0.01;								     
K2 = 0.03;								     
L = 255;                                  

C1 = (K1*L)^2;
C2 = (K2*L)^2;
window = window/sum(sum(window));
img1 = double(img1);
img2 = double(img2);

% automatic downsampling
f = max(1,round(min(M,N)/256));
%downsampling by f
%use a simple low-pass filter 
if(f>1)
    lpf = ones(f,f);
    lpf = (1./(f*f))*lpf;
    img1 = imfilter(img1,lpf,'symmetric','same');
    img2 = imfilter(img2,lpf,'symmetric','same');

    img1 = img1(1:f:end,1:f:end);
    img2 = img2(1:f:end,1:f:end);
end

mu1 = filter2(window, img1,'valid');
mu2 = filter2(window, img2,'valid');
mu1_sq = mu1.*mu1;
mu2_sq = mu2.*mu2;
mu1_mu2 = mu1.*mu2;
sigma1_sq = filter2(window, img1.*img1, 'valid') - mu1_sq;
sigma2_sq = filter2(window, img2.*img2, 'valid') - mu2_sq;
sigma12 = filter2(window, img1.*img2, 'valid') - mu1_mu2;
%____________________________________________
d1=blurindex(img1);
d2=blurindex(img2);
d1_sq=d1.*d1;
d2_sq=d2.*d2;
h=(2*d1.*d2+2*C2)./(d1_sq+d2_sq+2*C2);
h=mean2(h);

%___________________________________________
ssim_map = ((2*mu1_mu2 + C1).*(2*sigma12 + C2))./((mu1_sq + mu2_sq + C1).*(sigma1_sq + sigma2_sq + C2));

mssim = mean2(ssim_map)*h;
NSSIM=1-mssim;
return