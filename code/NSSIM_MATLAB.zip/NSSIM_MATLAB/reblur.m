function blurimg=reblur(img)
%PSF = fspecial('motion',5,45);
PSF=fspecial('gaussian',11,0.5);
blurimg = imfilter(img,PSF,'circular','conv');
return 