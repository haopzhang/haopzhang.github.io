function dindex=blurindex(img)

[M,N]=size(img);
pixelnum =M*N;
average=mean2(img);
d=[];
for value=0:255
    num=sum(sum(find(img==value)));
    p=num/pixelnum;
    if value<average
        w=value/average;
    else
        w=(255-value)/(255-average);
    end
    d(value+1)=p*w;
end
    
dindex=d;
return

